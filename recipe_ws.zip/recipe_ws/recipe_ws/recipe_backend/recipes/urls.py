from django.urls import path
from . import views

urlpatterns = [
    path('search_recipes/', views.search_recipes, name='search_recipes'),
    path('test_edamam/', views.test_edamam, name='test_edamam'),
]
