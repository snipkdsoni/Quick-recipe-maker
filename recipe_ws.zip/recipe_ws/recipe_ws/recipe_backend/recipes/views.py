import requests
from django.http import JsonResponse
from rest_framework.decorators import api_view
from decouple import config
import json

# Mock data for fallback
MOCK_RECIPES = [
    {
        'id': 'mock-1',
        'title': 'Chicken and Rice Casserole',
        'image_url': 'https://www.edamam.com/web-img/4f6/4f6b8c03e824eafd9083feb39a8a2e3d.jpg',
        'ingredients': [
            '1 lb chicken breast',
            '1 cup rice',
            '2 cups chicken broth',
            '1 can diced tomatoes',
            '1 onion, chopped',
            '2 cloves garlic, minced'
        ],
        'instructions': '1. Preheat oven to 375°F (190°C)\n2. Mix all ingredients in a baking dish\n3. Cover and bake for 45 minutes\n4. Uncover and bake for 15 more minutes',
        'nutrition_info': {
            'calories': {'amount': 450, 'unit': 'kcal'},
            'protein': {'amount': 35, 'unit': 'g'},
            'carbs': {'amount': 45, 'unit': 'g'},
            'fat': {'amount': 12, 'unit': 'g'}
        },
        'source_url': '#'
    }
]

def get_meal_plan_recipes(ingredients):
    """Fetch recipes using the Meal Planner API"""
    url = "https://api.edamam.com/api/meal-planner/recipes"
    params = {
        'q': ingredients,
        'app_id': config('EDAMAM_APP_ID', 'fc07aeac'),
        'app_key': config('EDAMAM_APP_KEY', '0dc10501c4d70f892270037db3b29396'),
        'random': 'true',
        'count': 5  # Number of recipes to return
    }
    
    response = requests.get(url, params=params)
    response.raise_for_status()
    return response.json()

@api_view(['GET'])
def search_recipes(request):
    ingredients = request.GET.get('ingredients', '')
    
    if not ingredients:
        return JsonResponse({'error': 'Please provide ingredients'}, status=400)
    
    try:
        # Edamam API v2 endpoint
        url = "https://api.edamam.com/api/recipes/v2"
        params = {
            'type': 'public',
            'q': ingredients,
            'app_id': config('EDAMAM_APP_ID', 'fc07aeac'),
            'app_key': config('EDAMAM_APP_KEY', '0dc10501c4d70f892270037db3b29396'),
        }
        headers = {
            'Edamam-Account-User': 'test_user'  # Required header
        }
        
        response = requests.get(url, params=params, headers=headers)
        response.raise_for_status()
        data = response.json()
        
        recipes = []
        for item in data.get('hits', [])[:5]:  # Limit to 5 recipes
            recipe = item.get('recipe', {})
            
            # Extract nutrition information
            nutrition = {
                'calories': {'amount': round(recipe.get('calories', 0)), 'unit': 'kcal'},
                'protein': {'amount': 0, 'unit': 'g'},
                'carbs': {'amount': 0, 'unit': 'g'},
                'fat': {'amount': 0, 'unit': 'g'}
            }
            
            # Get nutrition data if available
            for nutrient in recipe.get('totalNutrients', {}).values():
                label = nutrient.get('label', '').lower()
                if 'protein' in label:
                    nutrition['protein']['amount'] = round(nutrient.get('quantity', 0), 1)
                elif 'carb' in label:
                    nutrition['carbs']['amount'] = round(nutrient.get('quantity', 0), 1)
                elif 'fat' in label and 'saturated' not in label:
                    nutrition['fat']['amount'] = round(nutrient.get('quantity', 0), 1)
            
            recipes.append({
                'id': recipe.get('uri', '').split('#')[-1] if 'uri' in recipe else str(hash(recipe.get('label', ''))),
                'title': recipe.get('label', 'Untitled Recipe'),
                'image_url': recipe.get('image', ''),
                'ingredients': recipe.get('ingredientLines', []),
                'instructions': f"View full instructions at: {recipe.get('url', '')}",
                'nutrition_info': nutrition,
                'source_url': recipe.get('url', '#')
            })
        
        if recipes:
            return JsonResponse({'recipes': recipes})
            
        # Fall through to mock data if no recipes found
        return JsonResponse({'recipes': MOCK_RECIPES})
        
    except requests.exceptions.RequestException as e:
        # Fallback to mock data if API fails
        print(f"Error fetching from Edamam API: {str(e)}")
        return JsonResponse({
            'recipes': MOCK_RECIPES,
            'message': 'Using mock data due to API error'
        })
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return JsonResponse({
            'recipes': MOCK_RECIPES,
            'message': 'Using mock data due to an unexpected error'
        })

@api_view(['GET'])
def test_edamam(request):
    """Test endpoint to debug Edamam API"""
    url = "https://api.edamam.com/api/recipes/v2"
    params = {
        'type': 'public',
        'q': 'chicken',
        'app_id': 'fc07aeac',
        'app_key': '0dc10501c4d70f892270037db3b29396',
    }
    
    # Add required headers
    headers = {
        'Edamam-Account-User': 'test_user'  # Using a test user ID
    }
    
    try:
        response = requests.get(url, params=params, headers=headers)
        return JsonResponse({
            'status_code': response.status_code,
            'response': response.json() if response.status_code == 200 else response.text,
            'headers_sent': dict(response.request.headers)  # Show what headers were sent
        })
    except Exception as e:
        return JsonResponse({
            'error': str(e),
            'type': type(e).__name__
        }, status=500)