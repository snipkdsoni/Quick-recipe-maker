import React, { useState } from 'react';
import axios from 'axios';
import { FaSearch, FaUtensils, FaSpinner, FaRedo, FaAngleDown, FaAngleUp, FaExternalLinkAlt, FaInfoCircle } from 'react-icons/fa';

const RecipeSearch = () => {
  const [ingredients, setIngredients] = useState('');
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [expandedRecipe, setExpandedRecipe] = useState(null);
  const [searchPerformed, setSearchPerformed] = useState(false);

  const searchRecipes = async () => {
    if (!ingredients.trim()) {
      setError('Please enter at least one ingredient');
      return;
    }
    
    setLoading(true);
    setError(null);
    setSearchPerformed(true);
    
    try {
      const response = await axios.get('http://localhost:8000/api/search_recipes/', {
        params: { ingredients: ingredients },
        timeout: 10000 // 10 second timeout
      });
      setRecipes(response.data.recipes || []);
    } catch (err) {
      console.error('Error fetching recipes:', err);
      if (err.code === 'ECONNABORTED') {
        setError('Request timed out. Please try again.');
      } else if (err.response) {
        // Server responded with error status
        setError(err.response.data.error || 'Failed to fetch recipes. Please try again.');
      } else if (err.request) {
        // No response received
        setError('Unable to connect to the server. Please check your connection.');
      } else {
        // Other errors
        setError('An unexpected error occurred. Please try again.');
      }
      setRecipes([]);
    } finally {
      setLoading(false);
    }
  };

  const toggleRecipe = (index) => {
    setExpandedRecipe(expandedRecipe === index ? null : index);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    searchRecipes();
  };

  const formatNutritionInfo = (nutrition) => {
    if (!nutrition || Object.keys(nutrition).length === 0) {
      return (
        <div className="text-sm text-gray-500 flex items-center">
          <FaInfoCircle className="mr-1" /> Nutrition information not available
        </div>
      );
    }
    
    return (
      <div className="grid grid-cols-2 gap-2 text-sm">
        {Object.entries(nutrition).map(([key, value]) => (
          <div key={key} className="bg-white p-2 rounded shadow">
            <div className="font-medium text-gray-700 capitalize">{key}</div>
            <div className="text-indigo-600 font-semibold">
              {value.amount} {value.unit}
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8 min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-4 text-indigo-600">
          <FaUtensils className="inline-block mr-2" />
          Smart Recipe Finder from Leftovers
        </h1>
        <p className="text-center text-gray-600 mb-8">
          Enter ingredients you have on hand to discover delicious recipes!
        </p>
        
        <form onSubmit={handleSubmit} className="mb-12">
          <div className="flex flex-col sm:flex-row gap-2 shadow-lg rounded-lg overflow-hidden max-w-2xl mx-auto">
            <input
              type="text"
              value={ingredients}
              onChange={(e) => setIngredients(e.target.value)}
              placeholder="Enter ingredients (e.g., chicken, rice, tomatoes)..."
              className="flex-1 px-6 py-4 text-gray-700 focus:outline-none"
              disabled={loading}
            />
            <button
              type="submit"
              disabled={loading}
              className="bg-indigo-600 text-white px-6 py-4 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-colors disabled:opacity-75 flex items-center justify-center"
            >
              {loading ? (
                <>
                  <FaSpinner className="animate-spin mr-2" />
                  Searching...
                </>
              ) : (
                <>
                  <FaSearch className="mr-2" />
                  Find Recipes
                </>
              )}
            </button>
          </div>
          <p className="text-sm text-gray-500 mt-2 text-center">
            Separate ingredients with commas (e.g., "chicken, rice, tomatoes")
          </p>
        </form>

        {error && (
          <div className="max-w-2xl mx-auto bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-8 rounded">
            <p className="font-medium">Error</p>
            <p className="mb-2">{error}</p>
            <button
              onClick={searchRecipes}
              className="flex items-center text-sm text-red-700 font-semibold hover:underline"
              disabled={loading}
            >
              <FaRedo className="mr-1" /> Try Again
            </button>
          </div>
        )}

        {loading ? (
          <div className="text-center py-16">
            <FaSpinner className="animate-spin text-4xl text-indigo-500 mx-auto mb-4" />
            <p className="text-gray-600">Searching for delicious recipes...</p>
          </div>
        ) : recipes.length > 0 ? (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">
              Found {recipes.length} {recipes.length === 1 ? 'Recipe' : 'Recipes'}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recipes.map((recipe, index) => (
                <div 
                  key={recipe.id || index}
                  className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300 flex flex-col h-full"
                >
                  <div className="relative h-48 bg-gray-200">
                    {recipe.image_url ? (
                      <img
                        src={recipe.image_url}
                        alt={recipe.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.target.onerror = null;
                          e.target.src = 'https://via.placeholder.com/400x300?text=No+Image+Available';
                        }}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gray-100">
                        <FaUtensils className="text-gray-400 text-4xl" />
                      </div>
                    )}
                  </div>
                  
                  <div className="p-6 flex flex-col flex-grow">
                    <h2 className="text-xl font-bold mb-3 text-gray-800 line-clamp-2" title={recipe.title}>
                      {recipe.title}
                    </h2>
                    
                    <div className="mb-4">
                      <h3 className="font-semibold text-gray-700 mb-2 flex items-center justify-between">
                        <span>Ingredients</span>
                        <button 
                          onClick={() => toggleRecipe(index)}
                          className="text-sm text-indigo-600 hover:text-indigo-800 flex items-center"
                          aria-expanded={expandedRecipe === index}
                        >
                          {expandedRecipe === index ? (
                            <>
                              <span className="mr-1">Show less</span>
                              <FaAngleUp />
                            </>
                          ) : (
                            <>
                              <span className="mr-1">Show more</span>
                              <FaAngleDown />
                            </>
                          )}
                        </button>
                      </h3>
                      <div className={`overflow-hidden transition-all duration-300 ${expandedRecipe === index ? 'max-h-96' : 'max-h-20'}`}>
                        <ul className="list-disc list-inside text-gray-600 space-y-1">
                          {recipe.ingredients && recipe.ingredients.length > 0 ? (
                            recipe.ingredients.slice(0, expandedRecipe === index ? undefined : 3).map((ingredient, i) => (
                              <li key={i} className="text-sm">{ingredient}</li>
                            ))
                          ) : (
                            <li className="text-sm text-gray-500">No ingredients listed</li>
                          )}
                        </ul>
                      </div>
                    </div>

                    <div className="mt-auto">
                      {expandedRecipe === index && (
                        <>
                          <div className="mb-4">
                            <h3 className="font-semibold text-gray-700 mb-2">Nutrition Information</h3>
                            <div className="bg-gray-50 p-3 rounded-lg">
                              {formatNutritionInfo(recipe.nutrition_info)}
                            </div>
                          </div>
                        </>
                      )}

                      <div className="mt-4 pt-4 border-t border-gray-100 flex justify-between items-center">
                        {recipe.source_url && (
                          <a
                            href={recipe.source_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center text-indigo-600 hover:text-indigo-800 text-sm font-medium"
                          >
                            View Recipe <FaExternalLinkAlt className="ml-1 text-xs" />
                          </a>
                        )}
                        <button
                          onClick={() => toggleRecipe(index)}
                          className="text-sm text-gray-500 hover:text-gray-700"
                        >
                          {expandedRecipe === index ? 'Show less' : 'Show details'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : searchPerformed ? (
          <div className="text-center py-16 bg-white rounded-xl shadow-sm">
            <FaUtensils className="mx-auto text-5xl text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-700">No recipes found</h3>
            <p className="text-gray-500 mt-1">Try different ingredients or check your spelling.</p>
            <button
              onClick={() => setSearchPerformed(false)}
              className="mt-4 text-indigo-600 hover:text-indigo-800 font-medium"
            >
              Start a new search
            </button>
          </div>
        ) : null}
      </div>
    </div>
  );
};

export default RecipeSearch;