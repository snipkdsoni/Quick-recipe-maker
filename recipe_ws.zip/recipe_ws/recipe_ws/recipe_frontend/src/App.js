import React from 'react';
import RecipeSearch from './components/RecipeSearch';
import './index.css';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <main className="py-8">
        <RecipeSearch />
      </main>
      <footer className="text-center py-6 text-gray-500 text-sm">
        <p>Smart Recipe Finder &copy; {new Date().getFullYear()}</p>
      </footer>
    </div>
  );
}

export default App;