# Smart Recipe Finder from Leftovers

A full-stack web application that helps you find delicious recipes based on the ingredients you have on hand. The app fetches recipes from the Spoonacular API and provides detailed cooking instructions and nutrition information.

## Features

- Search for recipes using available ingredients
- View recipe details including ingredients and step-by-step instructions
- Access nutrition information for each recipe
- Responsive design that works on desktop and mobile devices
- Clean and intuitive user interface

## Tech Stack

- **Frontend**: React.js with Tailwind CSS
- **Backend**: Django REST Framework
- **APIs**:
  - Spoonacular API (for recipe data)

## Prerequisites

- Python 3.8+
- Node.js 16+
- npm or yarn
- Spoonacular API key (free tier available at https://spoonacular.com/food-api)

## Setup Instructions

### Backend Setup

1. Navigate to the backend directory:
   ```bash
   cd recipe_backend
   ```

2. Create and activate a virtual environment:
   ```bash
   # Windows
   python -m venv venv
   .\venv\Scripts\activate
   
   # macOS/Linux
   python3 -m venv venv
   source venv/bin/activate
   ```

3. Install backend dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Create a `.env` file in the `recipe_backend` directory with your API keys:
   ```
   SECRET_KEY=your_django_secret_key
   SPOONACULAR_API_KEY=your_spoonacular_api_key
   ```

5. Apply database migrations:
   ```bash
   python manage.py migrate
   ```

6. Start the backend server:
   ```bash
   python manage.py runserver
   ```
   The backend will be available at `http://localhost:8000`

### Frontend Setup

1. Open a new terminal and navigate to the frontend directory:
   ```bash
   cd ../recipe_frontend
   ```

2. Install frontend dependencies:
   ```bash
   npm install
   # or
   yarn install
   ```

3. Start the development server:
   ```bash
   npm start
   # or
   yarn start
   ```
   The frontend will be available at `http://localhost:3000`

## Usage

1. Open the application in your web browser at `http://localhost:3000`
2. Enter the ingredients you have available, separated by commas (e.g., "chicken, rice, tomatoes")
3. Click "Find Recipes" to search for recipes
4. Browse through the results and click on any recipe to see more details
5. Use the "Show more" button to view the full list of ingredients and instructions

## Project Structure

```
recipe_ws/
├── recipe_backend/           # Django backend
│   ├── recipe_project/       # Django project settings
│   ├── recipes/              # Recipes app
│   │   ├── __init__.py
│   │   ├── admin.py
│   │   ├── apps.py
│   │   ├── models.py
│   │   ├── serializers.py
│   │   ├── urls.py
│   │   └── views.py
│   ├── manage.py
│   └── requirements.txt
│
└── recipe_frontend/          # React frontend
    ├── public/               # Static files
    └── src/                  # React source code
        ├── components/       # Reusable components
        ├── App.js            # Main App component
        └── index.js          # Entry point
```

## Environment Variables

### Backend (`.env`)

- `SECRET_KEY`: Django secret key
- `SPOONACULAR_API_KEY`: Your Spoonacular API key

## Troubleshooting

- **CORS Errors**: Ensure the backend is running and CORS is properly configured in `settings.py`
- **API Limit Reached**: The free tier of Spoonacular has rate limits. Consider upgrading your plan if you hit these limits.
- **Missing Dependencies**: Make sure all dependencies are installed in both the backend and frontend.

## License

This project is open source and available under the [MIT License](LICENSE).

## Acknowledgments

- [Spoonacular API](https://spoonacular.com/food-api) for providing recipe data
- [React](https://reactjs.org/) and [Django](https://www.djangoproject.com/) for the tech stack
- [Tailwind CSS](https://tailwindcss.com/) for styling
